# a)
my_first_list = [1, 2, 3, 4, 5, 6]
print(my_first_list)

# b)
print(my_first_list[-1])

# c)
my_first_list[-2] = 'pluss'
print(my_first_list)

# d)
my_second_list = my_first_list[3:]
print(my_second_list)

# e)
ti = my_second_list[0] + my_second_list[2]
print(my_second_list, " er lik ", ti)
